<?php
	$url = 'http://webthefull.com/api/cardws';
	$partner_id = '0601968451';
	$partner_key = '6dd372151552c79c1fbabc49d02829f4';
	$wallet_number = '0071070849';


	///Hàm gọi curl
	function post_curl($url, $data){
	if(is_array($data))
            $dataPost = http_build_query($data);
        else
            $dataPost = $data;

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $dataPost);
        $actual_link = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
        curl_setopt($ch, CURLOPT_REFERER, $actual_link);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $result = curl_exec($ch);
        curl_close($ch);

        return $result;
	}


	///Hàm tạo chữ ký
    function createSign($partner_key, $data)
    {
        ksort($data);

        $sign = $partner_key;
        foreach ($data as $item) {
            $sign .= $item;
        }

        $sign = md5($sign);

        return $sign;
    }

	///Hàm giải mã
    function decrypt($partner_key, $code)
    {
        $encrypt_method = "AES-256-CBC";
        $key = hash('sha256', $partner_key);

        $iv = substr(hash('sha256', $key), 0, 16);

        $output = openssl_decrypt(base64_decode($code), $encrypt_method, $key, 0, $iv);
        return $output;
    }


?>