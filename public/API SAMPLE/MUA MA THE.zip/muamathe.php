<?php

require_once('config.php'); 
	
		///Loại thẻ và số lượng cần mua
		
        $Quantity = 2; // Số lượng . Kiểu Int
        $ServiceCode = 'Viettel'; // Mã dịch vụ xem ở bảng hướng dẫn
        $Amount = 50000; // Mệnh giá thẻ. Kiểu Int

		///Thông tin gửi lên
        $data['partner_id'] = $partner_id;
        $data['command'] = 'buycard';
        $data['wallet_number'] = $wallet_number;
        $data['request_id'] = 'NP_'.rand(10000,99999);   //Mã yêu cầu, có thể là mã giao dịch của bên bạn
        $data['service_code'] = 'Viettel';   ///Mã dịch vụ, xem ở bảng hướng dẫn
        $data['value'] = $Amount;
        $data['qty'] = $Quantity;
        $data['sign'] = createSign($partner_key, $data);

$result = post_curl($url, $data);

$result = json_decode($result, true);

if($result['status'] === 1){
	
	$card_list = $result['data']['cards'];
	
	foreach ($card_list as $card){
	
	$code = decrypt($partner_key, $card['code']);
	
                    if(substr($code, 0, 1) == '_'){
                        $code_e = explode("_", $code);
                        $manap = $code_e[1];
                    }else{
                        $manap = $code;
                    }

                    if(strpos($manap, "-")){
                        $manap = str_replace('-','',$manap);
                    }

	echo 'Thẻ '. $card['name'].', Mã nạp: '.$manap.', Serial: '.$card['serial'].'<br>';
	
	}
	

}else{
	/// Mua thẻ thất bại
	echo $result['message'];
}


?>